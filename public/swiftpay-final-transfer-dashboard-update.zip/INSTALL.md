# SwiftPay Installation & Deployment Guide

Follow these simple steps to apply this update package (`swiftpay-transfer-download-fix.zip`) to your existing SwiftPay project codebase.

---

## Installation Steps

1. **Extract the ZIP Archive**:
   Extract all contents from `swiftpay-transfer-download-fix.zip` on your computer.

2. **Open the Extracted Folder**:
   Open the folder containing the extracted update files (`src/`, `server.ts`, `db.ts`, `CHANGELOG.md`, `INSTALL.md`, etc.).

3. **Copy All Files & Folders**:
   Select and copy every file and folder from the extracted directory.

4. **Paste Into Root of Existing SwiftPay Project**:
   Paste the copied contents into the root directory of your existing SwiftPay project.

5. **Overwrite Existing Files**:
   When prompted by your operating system, choose **Replace / Overwrite All** to update the existing project files.

6. **Install Dependencies**:
   Open your terminal inside the SwiftPay project directory and run:
   ```bash
   npm install
   ```

7. **Commit & Push to GitHub**:
   ```bash
   git add .
   git commit -m "Apply latest SwiftPay polished update"
   git push origin main
   ```

8. **Redeploy on Render**:
   - Log into your Render dashboard (or your cloud hosting provider).
   - Trigger a manual deployment or allow automatic build from your `main` branch.
   - Verify that your application builds and deploys cleanly.

---

## Changed Files Included in This Package
- `src/App.tsx` (Route validation fix for `/dashboard/transfer`, popping popstate handler)
- `src/components/TransactionReceipt.tsx` (jsPDF direct PDF download implementation)
- `src/components/AdminPanel.tsx` (Replaced `window.print()` with CSV export)
- `src/components/BottomNav.tsx`
- `src/components/CyberWithdrawalTerminal.tsx`
- `src/components/ErrorBoundary.tsx`
- `server.ts` (Download ZIP endpoints & static file serving)
- `db.ts`
- `package.json` (Added `jspdf` dependency)
- `CHANGELOG.md`
- `INSTALL.md`

---
*Tested and verified for seamless mobile execution and PDF receipt generation.*
